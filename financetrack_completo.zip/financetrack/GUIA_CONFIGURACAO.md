# 🚀 Guia de Configuração — FinanceTrack com Firebase + Vercel

Siga este guia passo a passo. Leva cerca de **15–20 minutos** e é gratuito.

---

## 📋 O que você vai fazer

1. Criar projeto no Firebase (banco de dados na nuvem)
2. Ativar Login com Google
3. Criar banco de dados Firestore
4. Copiar as credenciais para o app
5. Publicar no GitHub
6. Hospedar no Vercel (link público para acessar de qualquer lugar)

---

## PASSO 1 — Criar projeto no Firebase

1. Acesse **https://console.firebase.google.com**
2. Clique em **"Criar um projeto"**
3. Nome do projeto: `financetrack-pessoal` (ou qualquer nome)
4. **Desative o Google Analytics** (não precisa para este projeto)
5. Clique em **"Criar projeto"** e aguarde

---

## PASSO 2 — Registrar seu App Web

1. Na tela inicial do projeto, clique no ícone **`</>`** (Web)
2. Nome do app: `FinanceTrack`
3. **NÃO marque** "Firebase Hosting" (vamos usar o Vercel)
4. Clique em **"Registrar app"**
5. Você verá um bloco de código assim:

```javascript
const firebaseConfig = {
  apiKey: "AIzaSy...",
  authDomain: "financetrack-xxxxx.firebaseapp.com",
  projectId: "financetrack-xxxxx",
  storageBucket: "financetrack-xxxxx.appspot.com",
  messagingSenderId: "123456789",
  appId: "1:123456789:web:abcdef"
};
```

> ⚠️ **COPIE ESSES DADOS — você vai precisar no Passo 4!**

6. Clique em **"Continuar para o console"**

---

## PASSO 3 — Ativar Login com Google

1. No menu lateral, clique em **"Build" → "Authentication"**
2. Clique em **"Começar"**
3. Clique em **"Google"** na lista de provedores
4. Ative o toggle (deve ficar azul)
5. Preencha **"E-mail de suporte do projeto"** com seu e-mail
6. Clique em **"Salvar"**

---

## PASSO 4 — Criar banco de dados Firestore

1. No menu lateral, clique em **"Build" → "Firestore Database"**
2. Clique em **"Criar banco de dados"**
3. Selecione **"Iniciar no modo de produção"**
4. Escolha a localização: **`southamerica-east1`** (São Paulo — mais rápido para o Brasil)
5. Clique em **"Ativar"**

### Configurar regras de segurança do Firestore:
1. Clique na aba **"Regras"**
2. **Apague tudo** que está lá e cole o seguinte:

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{userId}/{document=**} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
    }
  }
}
```

3. Clique em **"Publicar"**

> 🔒 Essa regra garante que cada usuário só acessa seus próprios dados.

---

## PASSO 5 — Colar as credenciais no app

1. Abra o arquivo **`public/index.html`** em um editor de texto
   (Bloco de Notas, VS Code, Notepad++ — qualquer um)

2. Encontre esta seção no início do arquivo (linha ~20):

```javascript
const firebaseConfig = {
  apiKey: "COLE_AQUI_apiKey",
  authDomain: "COLE_AQUI_authDomain",
  projectId: "COLE_AQUI_projectId",
  storageBucket: "COLE_AQUI_storageBucket",
  messagingSenderId: "COLE_AQUI_messagingSenderId",
  appId: "COLE_AQUI_appId"
};
```

3. **Substitua cada valor** pelos dados que você copiou no Passo 2.

Exemplo do resultado final:
```javascript
const firebaseConfig = {
  apiKey: "AIzaSyBxxxxxxxxxxxxxxxxxxxxxxxxx",
  authDomain: "financetrack-12345.firebaseapp.com",
  projectId: "financetrack-12345",
  storageBucket: "financetrack-12345.appspot.com",
  messagingSenderId: "987654321",
  appId: "1:987654321:web:abc123def456"
};
```

4. **Salve o arquivo**

---

## PASSO 6 — Publicar no GitHub

1. Acesse **https://github.com** e crie uma conta se não tiver
2. Clique em **"New repository"** (botão verde)
3. Nome: `financetrack`
4. Deixe como **Public** (necessário para o Vercel gratuito)
5. Clique em **"Create repository"**

### Fazer upload dos arquivos:
1. Na página do repositório criado, clique em **"uploading an existing file"**
2. Arraste os 3 arquivos da pasta `financetrack`:
   - `public/index.html`
   - `vercel.json`
   - `firestore.rules`
3. Escreva uma mensagem: `primeiro commit`
4. Clique em **"Commit changes"**

---

## PASSO 7 — Hospedar no Vercel

1. Acesse **https://vercel.com**
2. Clique em **"Sign Up"** e entre com sua conta **GitHub**
3. Clique em **"Add New → Project"**
4. Encontre seu repositório `financetrack` e clique em **"Import"**
5. Não mude nada — clique diretamente em **"Deploy"**
6. Aguarde ~1 minuto

Você receberá um link como:
```
https://financetrack-seuusuario.vercel.app
```

> 🎉 **Pronto! Esse é o link do seu app.** Acesse de qualquer dispositivo!

---

## PASSO 8 — Autorizar o domínio no Firebase

Este passo é obrigatório para o Login com Google funcionar:

1. Volte ao **Firebase Console**
2. Vá em **"Authentication" → "Settings" → "Authorized domains"**
3. Clique em **"Add domain"**
4. Cole seu domínio do Vercel: `financetrack-seuusuario.vercel.app`
5. Clique em **"Add"**

---

## ✅ Pronto! Checklist final

- [ ] Projeto Firebase criado
- [ ] Login Google ativado
- [ ] Firestore criado com regras de segurança
- [ ] Credenciais coladas no `index.html`
- [ ] Arquivos no GitHub
- [ ] App publicado no Vercel
- [ ] Domínio autorizado no Firebase

---

## 📱 Como usar em múltiplos dispositivos

- Acesse o link do Vercel em qualquer dispositivo
- Faça login com o **mesmo Google** em todos
- Os dados sincronizam **em tempo real** automaticamente
- No celular, adicione à tela inicial:
  - **iPhone:** Safari → Compartilhar → "Adicionar à Tela de Início"
  - **Android:** Chrome → Menu (⋮) → "Adicionar à tela inicial"

---

## ❓ Problemas comuns

| Problema | Solução |
|----------|---------|
| "Erro ao fazer login" | Verifique se o domínio do Vercel está autorizado no Firebase (Passo 8) |
| Tela em branco | Verifique se as credenciais estão corretas no `index.html` |
| "Permission denied" | Verifique as regras do Firestore (Passo 4) |
| Login não abre popup | Desative o bloqueador de pop-ups para o site |

---

*FinanceTrack — desenvolvido com Firebase + Vercel*
